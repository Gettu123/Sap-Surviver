(() => {
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;
  const $ = id => document.getElementById(id);
  const ui = {score:$('score'), level:$('level'), hearts:$('hearts'), tickets:$('tickets'), overlay:$('overlay'), title:$('overlay-title'), text:$('overlay-text'), start:$('start-btn'), toast:$('toast'), sound:$('sound-btn')};
  let running=false, score=0, lives=3, tickets=0, level=1, frame=0, spawn=0, bossMode=false, soundOn=true, audio=null;
  const keys={left:false,right:false,fire:false};
  const player={x:W/2,y:H-75,w:42,h:48,speed:6, cooldown:0, invuln:0};
  let enemies=[], bullets=[], sparks=[], pickups=[], stars=[];
  for(let i=0;i<85;i++) stars.push({x:Math.random()*W,y:Math.random()*H,s:Math.random()*2+0.5,v:Math.random()*1.3+0.3});
  const rand=(a,b)=>Math.random()*(b-a)+a;
  function beep(freq=440,duration=.07,type='square',vol=.035){if(!soundOn)return;try{audio=audio||new(window.AudioContext||window.webkitAudioContext)();const o=audio.createOscillator(),g=audio.createGain();o.type=type;o.frequency.value=freq;g.gain.value=vol;o.connect(g);g.connect(audio.destination);o.start();g.gain.exponentialRampToValueAtTime(.001,audio.currentTime+duration);o.stop(audio.currentTime+duration)}catch(e){}}
  function toast(msg){ui.toast.textContent=msg;ui.toast.classList.add('show');setTimeout(()=>ui.toast.classList.remove('show'),1100)}
  function updateHud(){ui.score.textContent=String(score).padStart(5,'0');ui.level.textContent=String(level).padStart(2,'0');ui.hearts.textContent='♥ '.repeat(lives).trim()||'—';ui.tickets.textContent=String(tickets).padStart(2,'0')}
  function start(){score=0;lives=3;tickets=0;level=1;frame=0;spawn=0;bossMode=false;enemies=[];bullets=[];sparks=[];pickups=[];player.x=W/2;player.invuln=0;running=true;ui.overlay.classList.add('hidden');updateHud();beep(660,.1)}
  function end(win=false){running=false;ui.title.textContent=win?'FOLHA FECHADA! 🏆':'GAME OVER — CHAMADO REABERTO';ui.text.textContent=win?'Você sobreviveu ao fechamento! A contabilidade confirmou: saldo zero para tudo.':'A folha parou, o prazo venceu e alguém comentou: “Mês passado estava funcionando!”. Tente novamente.';ui.start.textContent='JOGAR NOVAMENTE  ↻';ui.overlay.classList.remove('hidden');beep(win?880:130,.35,'sawtooth')}
  function spawnEnemy(){const boss=frame>2400 && !bossMode && Math.random()<.08;if(boss){bossMode=true;toast('🚨 CHEFÃO: FECHAMENTO DO MÊS!');enemies.push({x:W/2,y:-90,w:130,h:76,hp:18,boss:true,v:1.1});return}
    const types=[['CHAMADO', '#ff6175',1],['BUG', '#b88cff',1],['CUSTOM', '#ffad55',2],['EVIDÊNCIA', '#40dfc8',0]];
    const t=types[Math.floor(Math.random()*types.length)];
    enemies.push({x:rand(35,W-35),y:-45,w:t[0]==='CUSTOM'?48:38,h:38,hp:t[2],type:t[0],color:t[1],v:rand(1.5,2.8)+level*.18});
  }
  function shoot(){if(player.cooldown>0)return;bullets.push({x:player.x,y:player.y-22,v:8});player.cooldown=13;beep(590,.035,'square',.018)}
  function burst(x,y,color,n=12){for(let i=0;i<n;i++)sparks.push({x,y,vx:rand(-3,3),vy:rand(-3,3),life:rand(18,34),color})}
  function hit(){if(player.invuln>0)return;lives--;player.invuln=90;burst(player.x,player.y,'#ff6175',24);beep(100,.22,'sawtooth');toast('⚠ ENERGIA DO KEY USER REDUZIDA');updateHud();if(lives<=0)end()}
  function rectHit(a,b){return Math.abs(a.x-b.x)<(a.w+b.w)*.42&&Math.abs(a.y-b.y)<(a.h+b.h)*.42}
  function update(){
    frame++;if(keys.left)player.x-=player.speed;if(keys.right)player.x+=player.speed;player.x=Math.max(28,Math.min(W-28,player.x));
    if(keys.fire)shoot();if(player.cooldown>0)player.cooldown--;if(player.invuln>0)player.invuln--;
    spawn++;if(spawn>Math.max(25,75-level*5)){spawn=0;spawnEnemy()}
    if(frame%1500===0){level++;toast('FASE '+level+' — MAIS UM FECHAMENTO!');updateHud()}
    stars.forEach(s=>{s.y+=s.v;if(s.y>H){s.y=0;s.x=Math.random()*W}});
    bullets.forEach(b=>b.y-=b.v);bullets=bullets.filter(b=>b.y>-10);
    enemies.forEach(e=>{e.y+=e.v;if(e.boss)e.x+=Math.sin(frame*.025)*2.3;
      bullets.forEach((b,bi)=>{if(rectHit({x:b.x,y:b.y,w:8,h:18},e)){e.hp--;b.y=-50;burst(b.x,b.y,'#c7ff62',3);if(e.hp<=0){score+=e.boss?1500:100;tickets++;burst(e.x,e.y,e.color||'#ff6175',e.boss?40:16);if(e.boss){bossMode=false;setTimeout(()=>{if(running)end(true)},800)}if(Math.random()<.28)pickups.push({x:e.x,y:e.y,v:2});beep(260,.08,'triangle')}}});
      if(!e.boss&&e.y>H+30){e.y=-100;hit()}
      if(!e.boss&&rectHit(player,e)){e.y=H+100;hit()}
    });
    enemies=enemies.filter(e=>e.y<H+120&&e.hp>0);
    pickups.forEach(p=>{p.y+=p.v;if(rectHit(player,{x:p.x,y:p.y,w:18,h:18})){p.y=H+100;score+=50;toast('EVIDÊNCIA COLETADA +50');beep(900,.1,'sine')}});
    pickups=pickups.filter(p=>p.y<H+20);
    sparks.forEach(s=>{s.x+=s.vx;s.y+=s.vy;s.life--});sparks=sparks.filter(s=>s.life>0);
    if(frame%5===0)updateHud();
  }
  function drawGrid(){ctx.fillStyle='#061321';ctx.fillRect(0,0,W,H);ctx.strokeStyle='rgba(46,111,143,.12)';ctx.lineWidth=1;for(let x=0;x<W;x+=48){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke()}for(let y=0;y<H;y+=48){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}
    stars.forEach(s=>{ctx.fillStyle=`rgba(128,210,230,${.25+s.s*.2})`;ctx.fillRect(s.x,s.y,s.s,s.s)})}
  function text(str,x,y,size,color='#dffaff',align='center'){ctx.font=`bold ${size}px "Chakra Petch", monospace`;ctx.textAlign=align;ctx.fillStyle=color;ctx.fillText(str,x,y)}
  function drawPlayer(){if(player.invuln>0&&Math.floor(frame/5)%2===0)return;ctx.save();ctx.translate(player.x,player.y);
    ctx.shadowColor='#35e0d0';ctx.shadowBlur=18;ctx.fillStyle='#35e0d0';ctx.beginPath();ctx.moveTo(0,-27);ctx.lineTo(23,18);ctx.lineTo(0,10);ctx.lineTo(-23,18);ctx.closePath();ctx.fill();
    ctx.shadowBlur=0;ctx.fillStyle='#0b2639';ctx.fillRect(-12,-2,24,15);ctx.fillStyle='#c7ff62';ctx.fillRect(-7,-17,14,8);ctx.fillStyle='#edfaff';ctx.fillRect(-3,12,6,9);text('KEY USER',0,35,10,'#c7ff62');ctx.restore()}
  function drawEnemy(e){ctx.save();ctx.translate(e.x,e.y);ctx.shadowColor=e.color||'#ff5d6c';ctx.shadowBlur=15;ctx.fillStyle=e.color||'#ff5d6c';if(e.boss){ctx.fillRect(-e.w/2,-e.h/2,e.w,e.h);ctx.fillStyle='#401b2b';ctx.fillRect(-e.w/2+10,-e.h/2+12,e.w-20,e.h-24);ctx.fillStyle='#fff';ctx.fillRect(-35,-12,18,12);ctx.fillRect(17,-12,18,12);text('FECHAMENTO',0,8,17,'#fff');text('HP '+e.hp,0,55,11,'#ffb2ba')}else{ctx.fillRect(-e.w/2,-e.h/2,e.w,e.h);ctx.fillStyle='#18263b';ctx.fillRect(-e.w/2+5,-e.h/2+7,e.w-10,e.h-14);text(e.type==='CUSTOM'?'C':e.type==='BUG'?'!':'?',0,7,22,'#fff');text(e.type,e.x?0:0,32,9,'#fff')}ctx.restore()}
  function draw(){drawGrid();ctx.fillStyle='#35e0d0';bullets.forEach(b=>{ctx.shadowColor='#35e0d0';ctx.shadowBlur=12;ctx.fillRect(b.x-2,b.y,4,14)});ctx.shadowBlur=0;
    pickups.forEach(p=>{ctx.save();ctx.translate(p.x,p.y);ctx.rotate(frame*.04);ctx.fillStyle='#c7ff62';ctx.shadowColor='#c7ff62';ctx.shadowBlur=15;ctx.fillRect(-9,-9,18,18);ctx.restore()});
    enemies.forEach(drawEnemy);drawPlayer();sparks.forEach(s=>{ctx.globalAlpha=Math.max(0,s.life/30);ctx.fillStyle=s.color;ctx.fillRect(s.x,s.y,4,4)});ctx.globalAlpha=1;
    if(!running){ctx.fillStyle='rgba(5,15,27,.25)';ctx.fillRect(0,0,W,H)}
    text('SAP HCM  •  PAYROLL DEFENSE SYSTEM',18,25,11,'rgba(112,167,192,.55)','left');
  }
  function loop(){if(running)update();draw();requestAnimationFrame(loop)}
  ui.start.addEventListener('click',start);
  ui.sound.addEventListener('click',()=>{soundOn=!soundOn;ui.sound.textContent='♫ SOM: '+(soundOn?'LIGADO':'DESLIGADO');if(soundOn)beep(700,.08)});
  window.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight','Space'].includes(e.code))e.preventDefault();if(e.code==='ArrowLeft'||e.code==='KeyA')keys.left=true;if(e.code==='ArrowRight'||e.code==='KeyD')keys.right=true;if(e.code==='Space')keys.fire=true;if(e.code==='Enter'&&!running&&!ui.overlay.classList.contains('hidden'))start()});
  window.addEventListener('keyup',e=>{if(e.code==='ArrowLeft'||e.code==='KeyA')keys.left=false;if(e.code==='ArrowRight'||e.code==='KeyD')keys.right=false;if(e.code==='Space')keys.fire=false});
  function bindHold(id,key){const el=$(id);el.addEventListener('pointerdown',e=>{e.preventDefault();keys[key]=true});['pointerup','pointerleave','pointercancel'].forEach(ev=>el.addEventListener(ev,()=>keys[key]=false))}
  bindHold('left-btn','left');bindHold('right-btn','right');bindHold('fire-btn','fire');
  canvas.addEventListener('pointerdown',e=>{if(e.pointerType==='touch'){const r=canvas.getBoundingClientRect(),x=e.clientX-r.left;if(x<r.width*.35)keys.left=true;else if(x>r.width*.65)keys.right=true;else keys.fire=true}});
  canvas.addEventListener('pointerup',()=>{keys.left=keys.right=keys.fire=false});
  updateHud();draw();requestAnimationFrame(loop);
})();