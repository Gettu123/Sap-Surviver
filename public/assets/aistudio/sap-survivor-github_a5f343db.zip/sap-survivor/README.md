# SAP SURVIVOR — A Folha Não Pode Parar!

Um mini game arcade 2D, feito em HTML, CSS e JavaScript puro, com humor inspirado na rotina de SAP HCM, RH, Folha e Sustentação.

## Como jogar
- **← / →** ou **A / D**: mover o Key User
- **Espaço**: disparar / resolver chamados
- No celular: use os botões na tela ou toque nas laterais do campo.
- Colete os quadrados verdes (evidências) para ganhar pontos.
- Sobreviva aos chamados, bugs e customizações. Depois de algum tempo aparece o chefão **FECHAMENTO DO MÊS**.

## Rodar localmente
Basta abrir `index.html` em um navegador moderno. Não precisa instalar dependências ou executar servidor.

## Publicar no GitHub Pages
1. Crie um repositório público no GitHub, por exemplo `sap-survivor`.
2. Envie os arquivos `index.html`, `style.css`, `game.js` e `README.md` para a raiz do repositório.
3. Abra **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/ (root)`, depois clique em **Save**.
6. Aguarde a publicação. O GitHub mostrará o endereço público do jogo na própria página de Pages.

## Personalização
- Ajuste velocidade, frequência dos inimigos, pontuação e vida em `game.js`.
- Cores, tipografia e layout ficam em `style.css`.
- Textos, instruções e identidade visual ficam em `index.html`.

## Créditos
Projeto experimental criado para compartilhar humor e aprendizado sobre a comunidade SAP. SAP é marca de seus respectivos proprietários; este jogo é uma criação independente, sem vínculo oficial.
